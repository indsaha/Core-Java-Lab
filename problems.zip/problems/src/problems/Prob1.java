package problems;

public class Prob1 {
	public static void main(String args[]){
		/*int a[]={2,2,2,2,5,1,1};
		Solution s = new Solution();
		
		System.out.println(s.solution(a));*/
		int a[]={2,-4,6,-3,9};
		Solution1 s = new Solution1();
		
		System.out.println(s.solution(a));
	}

}
