package problems;

public class Solution1 {
	 public int solution(int[] a){
		 int min =0,t,g;
		 int c[]= new int[5],i,j,k=0;
		
	     int d[] = new int [5]; 
		 for(i=0;i<a.length-1;i++){
			 
				for(j=i+1;j<a.length;j++){
				  c[i]=c[i]+a[i]+a[j];
				  t=c[i];
				 g= Math.abs(t);
				  System.out.println(g);
				 d[k] = g;
				 System.out.println(d[k]);
				 k++;
				}
				
				
	 }
		 for(k=0;k<d.length;k++){
		    if(d[k]<d[k+1]){
		    	 min = d[k];
		    }
		    continue;
		 }
		 System.out.println(min);
		return min;
		

}
}
