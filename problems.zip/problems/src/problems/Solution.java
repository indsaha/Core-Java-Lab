package problems;

public class Solution {
	public int solution(int[] a)
	{
		int i,j,count=0,temp=0,max=0;
		
		for(i=0;i<a.length;i++){
			for(j=i;j<a.length;j++){
				if(a[i]==a[j]){
					count++;
				}
				else 
					continue;
			
			}
			//temp= count;
			 max= Math.max(max, count);
			 count=0;
		}
	  // max= Math.max(max, temp);
		if(max >a.length/2){
			//return max;
			return 1;
		}
		else
		{
			return -1;
		}
	}

}
